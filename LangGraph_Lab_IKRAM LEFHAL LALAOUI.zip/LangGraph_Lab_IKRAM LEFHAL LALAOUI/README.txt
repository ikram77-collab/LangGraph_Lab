# LangGraph Lab - Intelligent University Assistant

**Module:** FDO - M1 Agentic AI & Building AI Agents
**Author:** IKRAM LEFHALLALAOUI

## Description
This project implements a stateful, multi-agent AI system using LangGraph and LangChain. It features a Capstone project: an Intelligent University Assistant that routes student questions to specialized agents (Courses, Programming, Mathematics, Administration, General), handles tools (Calculator, Datetime), manages memory, and includes error handling.

## Setup & Requirements
To run this notebook, install the following dependencies:
```bash
pip install -U langgraph langchain langchain-openai langchain-community